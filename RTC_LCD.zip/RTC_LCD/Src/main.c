
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_hal.h"

/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdarg.h"

#define pgm_read_byte(x) (*(x))
#define RS 0x200    /* PA9 mask for reg select */ 
#define EN 0x80     /* PC7 mask for enable */
#define LINE1_HOME 0x80
#define LINE2_HOME 0xC0

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
uint16_t adc_raw; // result from ADC
char msg[20]= "";
uint8_t data_RTC[8];
uint8_t hour, min, sec, date, month, year2digit, day;	
int year4digit;
uint8_t daysInMonth[] = {31,28,31,30,31,30,31,31,30,31,30,31};
char name_of_theday[7][12] = {"Duminica","Luni","Marti","Miercuri","Joi","Vineri","Sambata"};
enum button {NO_PRESS, SELECT, LEFT, UP, DOWN, RIGHT};
enum button PRESSED_BUTTON = NO_PRESS;

enum flag {none, select_flag, left_flag, up_flag, down_flag, right_flag};
enum flag menu = none;

enum lines {LINE1, LINE2};
enum lines LINE;

enum clock_changes {no, ho, mi, se, da, mo, ye};
enum clock_changes clock_set = no;

uint8_t toggle_select = 1;
int8_t cursor = 0;
uint8_t temp_settings = 0;


int8_t hour_t, min_t, sec_t, date_t, month_t;
int year4digit_t;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void delayMs(int n);
void LCD_nibble_write(char data, uint16_t control);
void LCD_command(unsigned char command);
void LCD_data(char data);
void LCD_init(void);
void PORTS_init(void);
void print_string(char *s);
void vprint(const char *fmt, va_list argp);
void my_printf(const char *fmt, ...);
uint8_t BCD2DEC(uint8_t data);
uint8_t BCD2DEC(uint8_t data);
static uint16_t date2days(uint16_t y, uint8_t m, uint8_t d);
uint8_t dayOfTheWeek(int thn, int bln, int tgl);
void setRTC(uint8_t date,uint8_t mon,uint16_t year, uint8_t hour, uint8_t min, uint8_t sec);
void getRTC(void);
void select_button(void);
void move_right(void);
void move_left(void);
void move_up(void);
void move_down(void);
void select(void);



/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
/*
 Nucleo STM32F302R8 cu shield LCD cu butoane (tip Arduino) si DS1307 Tiny RTC
      Conexiuni
   =================
	 RTC     |  NUCLEO
	 =================
	 Vcc+    | +3V3
	 GND-    |  GND
	 SCL     |  PB8
	 SDA     |  PB9
	 
   =================
	 Shield  |  NUCLEO
	 =================
	 LCD R/S |  PA9
	 LCD EN  |  PC7
	 LCD D7  |  PA8
	 LCD D6  |  PB10
	 LCD D5  |  PB4
	 LCD D4  |  PB5
	 A0      |  PA0
	 
    Reglare
		- se apasa unul din butoanele UP, DOWN, LEFT, RIGHT si se alege campul care trebuie schimbat (apare cursorul)
					* daca nu se mai apasa nimic timp de cateva secunde, iese automat din acest mod si isi reia functionarea normala
		- se apasa SELECT (campul selectat va incepe sa clipeasca-blink)
		- se apasa UP/D0WN pentru a se stabili valoarea
		- se apasa SELECT si se asteapta cateva secunde
		- gata!

*/



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  RCC->AHBENR |= 0xC0000;       // enable clock for GPIOB and GPIOC
	GPIOB->MODER &= ~0xC000000;   // clear pin mode
	GPIOB->MODER |= 0x4000000;    // PB13 output mode
	GPIOC->MODER &= ~0x0C000000;    /* clear pin mode to input mode */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
			/* ADC
			vechi
		DEFAULT  3700-4095
		
		SELECT   2900-3200
		LEFT     2197-2450
		DOWN     1690
		UP        730
		RIGHT      0  
		*/
  /* initialize LCD controller */
	LCD_init();
	getRTC();
	hour_t = hour;
	min_t = min;
	sec_t = sec;
	date_t = date;
	month_t = month;
	year4digit_t = year4digit;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
		HAL_ADC_Start(&hadc1);
		HAL_ADC_PollForConversion(&hadc1, 100);
		adc_raw = HAL_ADC_GetValue(&hadc1);
		
		if ((GPIOC->IDR & 0x2000) == 0)    // if PC13 is low set date, clock etc
		{
			setRTC(1, 1, 2018, 12, 0, 0);	
      GPIOB->BSRR = 0x2000;    // turn on LED if time is set
      HAL_Delay(1500);	
			GPIOB->BSRR = 0x20000000;    // turn off LED
		}
		getRTC();
		char data_from_RTC[100];
		
		if(menu == none)
		{
			//HAL_Delay(1); 
			//LCD_command(0x0F);          /* turn on display, cursor blinking */
			//LCD_command(0x0E);          /* turn on display, cursor on, no blink */
			LCD_command(0x02);           // return cursor home
			sprintf(data_from_RTC, "Time:   %02d:%02d:%02d", hour, min, sec);
			print_string(data_from_RTC); // print on LCD
		
			LCD_command(0xC0);           // move  cursor to second line
			sprintf(data_from_RTC, "Date: %02d/%02d/%04d", date, month, year4digit);
			print_string(data_from_RTC); // print on LCD
			
		}
		
		if(menu == right_flag)
		{
			move_right();
		}
		if(menu == left_flag)
		{
			move_left();
		}
		if(menu == up_flag)
		{
			move_up();
		}
		if(menu == down_flag)
		{
			move_down();
		}
		if(menu == select_flag)
		{
			select();
		}

		select_button();

		if(PRESSED_BUTTON == RIGHT)
		{
			HAL_Delay(250);
			if (toggle_select == 1)
      {
				++cursor; // if cursor no blinking
				temp_settings = sec;
			}	
			if(cursor > 2) cursor = 2;
			PRESSED_BUTTON = NO_PRESS;
			menu = right_flag;	
		}
		
		
		if(PRESSED_BUTTON == LEFT)
		{
			HAL_Delay(250);
			if (toggle_select == 1)
			{
				--cursor; // if cursor no blinking
				temp_settings = sec;
			}				
			if(cursor <= 0) cursor = 0;
			PRESSED_BUTTON = NO_PRESS;
			menu = left_flag;
		}
		
		
		if(PRESSED_BUTTON == UP)
		{
			HAL_Delay(250);
			if (toggle_select == 1)
			{
				temp_settings = sec;
				LINE = LINE1;
			}	
			if (toggle_select == 0)  //if cursor blinking
	    {
        // SET TIME
		    if ((cursor == 0)&&(LINE == LINE1))  /*   hour  */
		    {
					char h_data[50];
					hour_t++;
					if(hour_t >= 24)
						hour_t = 23;
					LCD_command(0x02);           // return cursor home
					sprintf(h_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(h_data); // print on LCD
					LCD_command(0x89);          /*   hour */
					clock_set = ho;
				}
				if ((cursor == 1)&&(LINE == LINE1))  /*   min  */
		    {
					char m_data[50];
					min_t++;
					if(min_t >= 60)
						min_t = 59;
					LCD_command(0x02);           // return cursor home
					sprintf(m_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(m_data); // print on LCD
					LCD_command(0x8C);          /*   min */
					clock_set = mi;
				}
				if ((cursor == 2)&&(LINE == LINE1))  /*   sec  */
		    {
					char s_data[50];
					sec_t++;
					if(sec_t >= 60)
						sec_t = 59;
					LCD_command(0x02);           // return cursor home
					sprintf(s_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(s_data); // print on LCD
					LCD_command(0x8F);          /*   sec */
					clock_set = se;
				}
				
				// SET DATE
			  if ((cursor == 0)&&(LINE == LINE2))  /*   date  */
		    {
					char d_data[50];
					date_t++;
					if(date_t >= 31)
						date_t = 31;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(d_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(d_data); // print on LCD
					LCD_command(0xC7);          /*   date */
					clock_set = da;
				}
				if ((cursor == 1)&&(LINE == LINE2))  /*   month  */
		    {
					char m_data[50];
					month_t++;
					if(month_t >= 12)
						month_t = 12;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(m_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(m_data); // print on LCD
					LCD_command(0xCA);          /*   month */
					clock_set = mo;
				}
				if ((cursor == 2)&&(LINE == LINE2))  /*   year */
		    {
					char y_data[50];
					year4digit_t++;
					if(year4digit_t >= 2100)
						year4digit_t = 2100;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(y_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(y_data); // print on LCD
					LCD_command(0xCF);          /*   year */
					clock_set = ye;
				}
			}
			PRESSED_BUTTON = NO_PRESS;
			menu = up_flag;
		}
		
		
		if(PRESSED_BUTTON == DOWN)
		{
			HAL_Delay(250);
			if (toggle_select == 1)
			{
				temp_settings = sec;
				LINE = LINE2;
			}
			if (toggle_select == 0)  //if cursor blinking
	    {
        // SET TIME
		    if ((cursor == 0)&&(LINE == LINE1))  /*   hour */
		    {
					char h_data[50];
					hour_t--;
					if(hour_t < 0)
						hour_t = 0;
					LCD_command(0x02);           // return cursor home
					sprintf(h_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(h_data); // print on LCD
					LCD_command(0x89);          /*   hour */
					clock_set = ho;
				}
				if ((cursor == 1)&&(LINE == LINE1))  /*   min */
		    {
					char m_data[50];
					min_t--;
					if(min_t < 0)
						min_t = 0;
					LCD_command(0x02);           // return cursor home
					sprintf(m_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(m_data); // print on LCD
					LCD_command(0x8C);          /*   min */
					clock_set = mi;
				}
				if ((cursor == 2)&&(LINE == LINE1))  /*   sec */
		    {
					char s_data[50];
					sec_t--;
					if(sec_t < 0)
						sec_t = 0;
					LCD_command(0x02);           // return cursor home
					sprintf(s_data, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);
					print_string(s_data); // print on LCD
					LCD_command(0x8F);          /*   sec */
					clock_set = se;
				}
				
				
								// SET DATE
			  if ((cursor == 0)&&(LINE == LINE2))  /*   date  */
		    {
					char d_data[50];
					date_t--;
					if(date_t < 1)
						date_t = 1;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(d_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(d_data); // print on LCD
					LCD_command(0xC7);          /*   date */
					clock_set = da;
				}
				if ((cursor == 1)&&(LINE == LINE2))  /*   month  */
		    {
					char m_data[50];
					month_t--;
					if(month_t < 1)
						month_t = 1;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(m_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(m_data); // print on LCD
					LCD_command(0xCA);          /*   month */
					clock_set = mo;
				}
				if ((cursor == 2)&&(LINE == LINE2))  /*   year */
		    {
					char y_data[50];
					year4digit_t--;
					if(year4digit_t < 2000)
						year4digit_t = 2000;
					LCD_command(0xC0);           // move  cursor to second line
					sprintf(y_data, "Date: %02d/%02d/%04d", date_t, month_t, year4digit_t);
					print_string(y_data); // print on LCD
					LCD_command(0xCF);          /*   year */
					clock_set = ye;
				}
			}
			PRESSED_BUTTON = NO_PRESS;
			menu = down_flag;
		}
		
		
		if(PRESSED_BUTTON == SELECT)
		{
			HAL_Delay(250);
			PRESSED_BUTTON = NO_PRESS;
			if (menu != none)
			{
				PRESSED_BUTTON = NO_PRESS;
			  menu = select_flag;
			  toggle_select =! toggle_select;
				if (toggle_select == 1)
				{
					temp_settings = sec;	
				}
		  }
		}
		
	if ((menu != none)&&(toggle_select == 1)) // if stay too long exit from settings (and save)
	{
		if(abs(temp_settings - sec) > 8)
		{
			menu = none;
			cursor = 0;
			temp_settings = 0;
			// if clock was changed save it
			if ((clock_set == ho)||(clock_set == mi)||(clock_set == se)||(clock_set == da)||(clock_set == mo)||(clock_set == ye))
			{
				setRTC(date_t, month_t, year4digit_t, hour_t, min_t, sec_t);
				LCD_command(0x02);           // return cursor home
				sprintf(data_from_RTC, "Time:   %02d:%02d:%02d", hour_t, min_t, sec_t);				
				print_string(data_from_RTC); // print on LCD
				clock_set = no;
			}
		}	
	}
		
		switch (menu){
			case right_flag:
				move_right();
				//menu = none;
				break;
			case left_flag:
				move_left();
				//menu = none;
				break;
			case up_flag:
				move_up();
				//menu = none;
				break;
			case down_flag:
				move_down();
				//menu = none;
				break;
			case select_flag:
				select();
		  	//menu = none;
				break;
			default:
				menu = none;
				break;
			}
		
		//HAL_Delay(1000); 
		//GPIOB->BSRR = 0x20000000;    // turn off LED
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_ADC1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.Adc1ClockSelection = RCC_ADC1PLLCLK_DIV1;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* I2C1 init function */
static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Analogue filter 
    */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Digital filter 
    */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
/* initialize GPIOA/B/C then initialize LCD controller */
void LCD_init(void) {
    PORTS_init();
              /* LCD controller reset sequence */
	  HAL_Delay(20); 
    LCD_nibble_write(0x30, 0);
	  HAL_Delay(5); 
    LCD_nibble_write(0x30, 0);
	  HAL_Delay(1); 
    LCD_nibble_write(0x30, 0);
	  HAL_Delay(1); 

    LCD_nibble_write(0x20, 0);  /* use 4-bit data mode */
	  HAL_Delay(1); 
    LCD_command(0x28);          /* set 4-bit data, 2-line, 5x7 font */
    LCD_command(0x06);          /* move cursor right (increment automatically, no display shift) */
    LCD_command(0x01);          /* clear screen, move cursor to home */
	  HAL_Delay(1); 
		HAL_Delay(1); 
		LCD_command(0x0E);          /* turn on display, cursor on, no blink */
	  //LCD_command(0x0C);            /* turn on display, no cursor*/
}

void PORTS_init(void) {
    RCC->AHBENR |=  0xE0000;          /* enable GPIOA/B/C clock */

    /* PORTA 9 for LCD R/S */
    /* PORTC 7 for LCD EN */
	
	  //clear pin mode 
	  GPIOA->MODER &= ~0xF0000;  // A8  A9
	  GPIOB->MODER &= ~0x300F00; //  B4 B5 B10 
	  GPIOC->MODER &= ~0xC000;   //  C7
    
    GPIOA->MODER |=  0x50000;     /* set pin output mode */
	  GPIOB->MODER |=  0x100500;    /* set pins output mode */
	  GPIOC->MODER |=  0x4000;      /* set pin output mode */
	
    GPIOC->BSRR = 0x800000;      /* turn off EN */

    /* PA8, PB10, PB4, PB5 for LCD D7-D4, respectively. */
    //GPIOA->MODER |= 0x10000;    /* set pin output mode  */
    //GPIOB->MODER |= 0x100500;    /* set pins output mode */
}

void LCD_nibble_write(char data, uint16_t control) {
    /* populate data bits */
    GPIOA->BSRR = 0x1000000;       /* clear data bit PA8 */
	  GPIOB->BSRR = 0x4300000;       /* clear data bits PB4 PB5 PB10 */
	
	  GPIOA->BSRR = (data << 1) & 0x100;   /* bit PA8   D7 */
    GPIOB->BSRR = (data << 4) & 0x400;   /* bit PB10  D6 */
	  GPIOB->BSRR = (data >> 1) & 0x10;    /* bit PB4   D5 */
	  GPIOB->BSRR = (data << 1) & 0x20;    /* bit PB5   D4 */
	
	
    /* set R/S bit */
    if (control & RS)
        GPIOA->BSRR = RS;
    else
        GPIOA->BSRR = RS << 16; //reset

    /* pulse E */
    GPIOC->BSRR = EN;
    //delayMs(0);
		HAL_Delay(0); 
    GPIOC->BSRR = EN << 16;  //reset
}

void LCD_command(unsigned char command) {
    LCD_nibble_write(command & 0xF0, 0);    /* upper nibble first */
    LCD_nibble_write(command << 4, 0);      /* then lower nibble */

    if (command < 4)
        //delayMs(2);         /* command 1 and 2 needs up to 1.64ms */
		    HAL_Delay(2); 
    else
        //delayMs(1);         /* all others 40 us */
				HAL_Delay(1); 
}

void LCD_data(char data) {
    LCD_nibble_write(data & 0xF0, RS);      /* upper nibble first */
    LCD_nibble_write(data << 4, RS);        /* then lower nibble */
    //delayMs(1);
	  HAL_Delay(1); 
}

void print_string(char *s)
{
  uint8_t string_length = strlen(s);
	for(uint8_t i = 0; i < string_length; ++i)
	{
		char character = s[i];
		LCD_data(character);
	}
}
// UART
void vprint(const char *fmt, va_list argp)
{
	char string[200];
	if(0 < vsprintf(string, fmt,argp))  // build string
	{
		HAL_UART_Transmit(&huart2, (uint8_t*)string, strlen(string), 0xffffff);
	}
}

void my_printf(const char *fmt, ...)  // custom printf() function
{
	va_list argp;
	va_start(argp, fmt);
	vprint(fmt, argp);
	va_end(argp);
}

// functions for RTC ===============================================
// add function to convert BCD to decimal and decimal to BCD
uint8_t BCD2DEC(uint8_t data)
{
	return (data>>4)*10+(data&0x0F);
}

uint8_t DEC2BCD(uint8_t data)
{
	return (data/10)<<4|(data%10);
}


static uint16_t date2days(uint16_t y, uint8_t m, uint8_t d)
{
	if(y >= 2000)
		y -= 2000;
	uint16_t days = d;
	for(uint8_t i = 1; i < m; ++i)
		days += pgm_read_byte(daysInMonth + i -1);
	   // days += read_byte(daysInMonth + i -1);
	if (m > 2 && y % 4 == 0)
		++days;
	return days + 365 * y + (y + 3)/4 - 1;
}

uint8_t dayOfTheWeek(int thn, int bln, int tgl)
{
	uint16_t day = date2days(thn, bln, tgl);
	return (day + 6) % 7; // Jan 1, 2000 is a Saturday, i.e. return 6
}

// function to call data from DS1307 to STM32
void getRTC()
{
	data_RTC[0] = 0x00;
	HAL_I2C_Master_Transmit(&hi2c1, 0xD0, data_RTC, 1, 50);
	HAL_I2C_Master_Receive(&hi2c1, 0xD0, data_RTC, 7, 50);
	
	hour = BCD2DEC(data_RTC[2]);
	min = BCD2DEC(data_RTC[1]);
	sec = BCD2DEC(data_RTC[0]);
	
	year2digit = BCD2DEC(data_RTC[6]);
	month = BCD2DEC(data_RTC[5]);
	date = BCD2DEC(data_RTC[4]);
	
	year4digit = 2000 + (year2digit%100);
	day = dayOfTheWeek(year2digit, month, date); 	
}

//function to set time and date
void setRTC(uint8_t date, uint8_t mon, uint16_t year, uint8_t hour, uint8_t min, uint8_t sec){
   uint8_t data_RTC[8];

   data_RTC[0] = 0x00;
   data_RTC[1] = DEC2BCD(sec);  //set seconds
   data_RTC[2] = DEC2BCD(min); //set minute
   data_RTC[3] = DEC2BCD(hour); //set hour

   data_RTC[5] = DEC2BCD(date);  //set date
   data_RTC[6] = DEC2BCD(mon); //set month
   data_RTC[7] = DEC2BCD(year-2000);   //set year

   HAL_I2C_Master_Transmit(&hi2c1,0xD0,data_RTC,8,50); 
   HAL_Delay(100);   
}

/* delay n milliseconds (16 MHz CPU clock) */
void delayMs(int n) {
    int i;
    for (; n > 0; n--)
        for (i = 0; i < 2195; i++) ;
}

void select_button()
{	
	if(adc_raw <= 100){
		PRESSED_BUTTON = RIGHT;
  } 
	else if (adc_raw <= 500) {
	  PRESSED_BUTTON = UP;	 
  }
	else if (adc_raw <= 1200) {
		PRESSED_BUTTON = DOWN;
	} 
	else if (adc_raw <= 1650) { 
	 PRESSED_BUTTON = LEFT;
	}
	else if (adc_raw <= 2200) {
	 PRESSED_BUTTON = SELECT;
  } 		
}

void move_right()
{
	if ((toggle_select == 1)&&(LINE == LINE1))  // if cursor no blinking and line1
	//if (line == LINE1)  // if cursor no blinking and line1
	{
		if(cursor == 0)
			LCD_command(0x89);          /*   hour */
		if(cursor == 1)
			LCD_command(0x8C);          /*   minute */
		if(cursor == 2)
			LCD_command(0x8F);          /*   seconds */
	}
	//if ((toggle_select == 1)&&(line == LINE2))  // if cursor no blinking and line2
	if (LINE == LINE2)  // if cursor no blinking and line2
	{
		if(cursor == 0)
			LCD_command(0xC7);          /*   day */
		if(cursor == 1)
			LCD_command(0xCA);          /*   month */
		if(cursor == 2)
			LCD_command(0xCF);          /*   year */		
	}
		
}
void move_left()
{
	//if ((toggle_select == 1)&&(line == LINE1))  // if cursor no blinking and line1
	if ((toggle_select == 1)&&(LINE == LINE1))  // if cursor no blinking and line1
	{
		if(cursor == 0)
			LCD_command(0x89);          /*   hour */
		if(cursor == 1)
			LCD_command(0x8C);          /*   minute */
		if(cursor == 2)
			LCD_command(0x8F);          /*   seconds */	
	}
	//if ((toggle_select == 1)&&(line == LINE2))  // if cursor no blinking and line2
	if ((toggle_select == 1)&&(LINE == LINE2))  // if cursor no blinking and line2
	{
		if(cursor == 0)
			LCD_command(0xC7);          /*   day */
		if(cursor == 1)
			LCD_command(0xCA);          /*   month */
		if(cursor == 2)
			LCD_command(0xCF);          /*   year */		
	}
}
void move_up()
{
	
	if (toggle_select == 1)  //if cursor no blinking
	{
		LCD_command(0x89);          /*  first line (hour)*/
	  LINE = LINE1; 
		if(clock_set == ho)
		{
			cursor = 0;
			//LCD_command(0xC7);          /*   second line (day) */
		}
		if(clock_set == mi)
		{
			cursor = 1;
			//LCD_command(0xC7);          /*   second line (day) */
		}
		if(clock_set == se)
		{
			cursor = 2;
			//LCD_command(0xC7);          /*   second line (day) */
		}
		//
	}
	
}

void move_down()
{
	
	if (toggle_select == 1) //if cursor no blinking
	{
		LCD_command(0xC7);          /*   second line (day) */
		LINE = LINE2;
		if(clock_set == da)
		{
			cursor = 0;
			
		}
		if(clock_set == mo)
		{
			cursor = 1;
			
		}
		if(clock_set == ye)
		{
			cursor = 2;
			
		}

	}	

}
void select()
{
	if (toggle_select == 0)
	  LCD_command(0x0F);          /* turn on display, cursor blinking */
	else
	{
		LCD_command(0x0E);          /* turn on display, cursor on, no blink */
		
	}
		
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
