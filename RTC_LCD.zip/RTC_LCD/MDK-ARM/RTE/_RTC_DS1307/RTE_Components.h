
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RTC_DS1307' 
 * Target:  'RTC_DS1307' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f3xx.h"

#define RTE_Compiler_EventRecorder
          #define RTE_Compiler_EventRecorder_DAP

#endif /* RTE_COMPONENTS_H */
